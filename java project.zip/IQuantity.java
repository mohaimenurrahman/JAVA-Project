package project;
import java.lang.*;

public interface IQuantity {

	void addQuantity(int amount);
	void sellQuantity(int amount);
}
